from auth.auth_helper import make_request

print(make_request(test='test'))